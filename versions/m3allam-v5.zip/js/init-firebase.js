var firebaseConfig = {
  apiKey: "AIzaSyBeyUrDTyFGawnaLFmDyb7DxHn6IscQK4Y",
  authDomain: "m3allam-cbaae.firebaseapp.com",
  databaseURL: "https://m3allam-cbaae.firebaseio.com",
  projectId: "m3allam-cbaae",
  storageBucket: "m3allam-cbaae.appspot.com",
  messagingSenderId: "500791146307",
  appId: "1:500791146307:web:7e8055379df2c4d06ea1f6",
};
firebase.initializeApp(firebaseConfig);
firebase.auth().languageCode = 'ar';