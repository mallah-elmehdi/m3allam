const indexController = require("../controller/indexController");
const authController = require("../controller/authController");
const errController = require("../controller/errController");
const express = require("express");
const router = express.Router();

router
  .route("/")
  .get(
    authController.userLoggedIn,
    indexController.indexPage,
    errController.indexError,
    errController.globalError
  )
  .post(indexController.indexSearch);

router
  .route("/resultat")
  .get(
    authController.userLoggedIn,
    indexController.resultatPage,
    errController.indexError,
    errController.globalError

  );

router
  .route("/ouvrier")
  .get(
    authController.userLoggedIn,
    indexController.ouvrierPage,
    errController.indexError,
    errController.globalError
  );

router
  .route("/service")
  .get(
    authController.userLoggedIn,
    indexController.servicePage,
    errController.indexError,
    errController.globalError
  );

  router
  .route("/deconnecter")
  .get(
    authController.userLoggedIn,
    indexController.logOut,
    errController.indexError,
    errController.globalError
  );

router.get("/politique-de-confidentialite", indexController.privacyPage);

module.exports = router;
