$(document).ready(function () {
  $(".service").mouseover(function () {
    $(this).addClass("shadow");
    $(".service").mouseout(function () {
      $(this).removeClass("shadow");
    });
  });

  $.getJSON(`../json/${$("#jiha").val()}.json`, function (result) {
    $.each(result, function (i) {
      if (result[i].type === $("#city").data("city"))
        $("#city").append(
          `<option value='${result[i].type}' selected >${result[i].type}</option>`
        );
      else
        $("#city").append(
          `<option value='${result[i].type}'>${result[i].type}</option>`
        );
    });
  });

  $("#jiha").change(function () {
    $("input.d-none[name=jiha]").attr("value", $(this).val());
    $("#city").empty();
    $.getJSON(`../json/${$(this).val()}.json`, function (result) {
      $.each(result, function (i) {
        $("#city").append(
          `<option value='${result[i].type}'>${result[i].type}</option>`
        );
      });
    });
  });

  $("#city").change(function () {
    $("input.d-none[name=city]").attr("value", $(this).val());
  });
});
