const fs = require("fs");
const user = require("../model/userModel");
const service = require("../model/serviceModel");
const appError = require("../utils/appErrors");
const catchAsync = require("../utils/catchAsync");
const multer = require("multer");
const sharp = require("sharp");

const jobs = JSON.parse(fs.readFileSync(`${__dirname}/../json/jobs.json`));
const jihat = JSON.parse(fs.readFileSync(`${__dirname}/../json/jiha.json`));

// ========================= PICTURE CROP

const multerStorage = multer.memoryStorage();

const multerFilter = (req, file, cb) => {
  if (file.mimetype.startsWith("image")) {
    cb(null, true);
  } else {
    cb(new appError("ليست صورة! يرجى تحميل الصور فقط", 400), false);
  }
};

const upload = multer({
  storage: multerStorage,
  fileFilter: multerFilter,
});

exports.uploadStoreLogo = upload.single("picture");

exports.resizeStoreLogo = catchAsync(async (req, res, next) => {
  if (!req.file) return next();
  req.file.filename = `service-${res.locals.user.id}-${Date.now()}.png`;

  await sharp(req.file.buffer)
    .resize(750, 463)
    .toFormat("png")
    .jpeg({ quality: 90 })
    .toFile(`${__dirname}/../graphics/service/${req.file.filename}`);
  next();
});

// ========================= GET

exports.monComptePage = async (req, res) => {
  const services = await service.find({ user: req.query.id }).populate("user");

  res.status(200).render("monCompte", {
    title: "m3allam.ma | حسابي",
    services,
    jobs,
  });
};

exports.ajouterService = (req, res) => {
  res.status(200).render("ajouterService", {
    title: "m3allam.ma | أضف خدمة",
    jobs,
  });
};

exports.mesInfos = (req, res) => {
  res.status(200).render("mesInfos", {
    title: "m3allam.ma | معلوماتي",
    jobs,
    jihat,
  });
};

// =================== POST

exports.saveService = catchAsync(async (req, res, next) => {
  const addService = await service.create({
    service: req.body.service,
    experience: req.body.experience,
    explain: req.body.explain.toLowerCase(),
    user: req.query.id,
    picture: req.file.filename,
  });

  if (!addService)
    return next(
      new appError("حدث خطأ ما. لم يتم إنشاء خدمة، أعد المحاولة من فضلك", 500)
    );

  res.redirect(`/mon-compte?id=${req.query.id}`);
});

exports.changeInfos = catchAsync(async (req, res, next) => {
  if (!req.file) var photo = res.locals.user.photo;
  else {
    var photo = req.file.filename;
    fs.unlink(
      `${__dirname}/../graphics/worker/${res.locals.user.photo}`,
      (err) => {
        if (err)
          return next(new appError("حدث خطأ ما. أعد المحاولة من فضلك", 500));
      }
    );
  }

  const updateUser = await user.findByIdAndUpdate(
    req.query.id,
    {
      name: req.body.name,
      jiha: req.body.jiha,
      city: req.body.city,
      whatsapp: req.body.whatsapp,
      phone: "+212" + req.body.phone.substring(1),
      photo,
    },
    { new: true }
  );

  if (!updateUser)
    return next(new appError("حدث خطأ ما. أعد المحاولة من فضلك", 500));

  res.redirect(`/mon-compte/mes-informations?id=${req.query.id}`);
});

// =================== DELETE

exports.deleteService = catchAsync(async (req, res, next) => {
  const deleteServ = await service.findByIdAndDelete(req.query.sid);
  if (!deleteServ)
    return next(
      new appError("حدث خطأ ما. لم يتم إنشاء خدمة، أعد المحاولة من فضلك", 500)
    );
  fs.unlink(`${__dirname}/../graphics/service/${deleteServ.picture}`, (err) => {
    if (err) return next(new appError("حدث خطأ ما. أعد المحاولة من فضلك", 500));
  });
  res.redirect(`/mon-compte?id=${req.query.id}`);
});
