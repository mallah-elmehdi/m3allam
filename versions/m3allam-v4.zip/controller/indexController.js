const fs = require("fs");
const service = require("../model/serviceModel");
const user = require("../model/userModel");
const catchAsync = require("../utils/catchAsync");
const appError = require("../utils/appErrors");
const slugify = require("slugify");

const jobs = JSON.parse(fs.readFileSync(`${__dirname}/../json/jobs.json`));
const jihat = JSON.parse(fs.readFileSync(`${__dirname}/../json/jiha.json`));

var g_jiha;
var g_city;
var g_service;

// =============================================================== INDEX PAGE

exports.indexPage = catchAsync(async (req, res, next) => {
  var message = "";
  var status = 200;
  var i = 0;
  var j = 0;

  if (req.query.message) message = req.query.message;
  if (req.query.status) status = req.query.status;
  var services = [];

  while (i < jobs.length) {
    var ele = await service
      .find({ service: jobs[i].fr })
      .populate("user")
      .limit(8);

    if (ele.length >= 4) {
      services[j] = { id: jobs[i].fr, service: jobs[i].ar, content: ele };
      j++;
    }
    i++;
  }

  res.status(status).render("index", {
    title: "m3allam.ma | أفضل خدمات الأشغال عمومية",
    jobs,
    services,
    message,
    jihat,
  });
});

// =============================================================== RESULTAT PAGE

exports.resultatPage = catchAsync(async (req, res, next) => {
  var services = [];
  var ele;
  var i = 0;

  if (req.params.service && req.params.search) {
    var expression = req.params.search.split("-");
    var exp = [];
    while (i < expression.length) {
      exp[i] = new RegExp(expression[i]);
      i++;
    }
    ele = await service
      .find({ service: g_service, explain: { $in: exp } })
      .populate("user");
  } 
  
  else if (req.params.searchANDservice) {

    if (g_service)
      ele = await service.find({ service: g_service }).populate("user");

    else {
      var expression = req.params.searchANDservice.split("-");
      var exp = [];
      while (i < expression.length) {
        exp[i] = new RegExp(expression[i]);
        i++;
      }
      ele = await service.find({ explain: { $in: exp } }).populate("user");
    }
  } 
  
  else {
    ele = await service.find().populate("user");
  }

  var a = 0;
  var k = 0;
  
  while (a < ele.length) {
    if (ele[a].user.city.fr === g_city) {
      services[k] = ele[a];
      k++;
    }
    a++;
  }

  res.status(200).render("resultat", {
    title: "m3allam.ma | الخدمة",
    jobs,
    jihat,
    services,
    g_jiha,
    g_city,
  });
});

// =============================================================== POST

exports.indexSearch = (req, res) => {
  
  g_jiha = req.body.jiha;
  g_city = JSON.parse(req.body.city).fr;
  g_service = req.body.service;

  if (req.body.service && req.body.search != "") {
    res.redirect(`/ar/${slugify(g_city, { lower: true })}/${slugify(req.body.service,{ lower: true })}/${slugify(req.body.search, {lower: true,})}`);
  } 
  
  else if (req.body.service && req.body.search === "") {
    res.redirect(`/ar/${slugify(g_city, { lower: true })}/${slugify(req.body.service,{ lower: true })}`);
  } 
  
  else if (!req.body.service && req.body.search != "") {
    res.redirect(`/ar/${slugify(g_city, { lower: true })}/${slugify(req.body.search,{lower: true,})}`);
  } 
  
  else {
    res.redirect(`/ar/${slugify(g_city, { lower: true })}`);
  }
};

// =============================================================== PRIVACY

exports.privacyPage = (req, res) => {
  res.status(200).render("privacy", {
    title: "m3allam.ma | سياسة الخصوصية",
  });
};

exports.logOut = (req, res, next) => {
  try {
    if (!res.locals.user) return res.redirect("/");
    res.clearCookie("cookie");
    return res.redirect("/");
  } catch (err) {
    next(err);
  }
};

// =============================================================== SERVICE PAGE

exports.servicePage = catchAsync(async (req, res, next) => {
  const serv = await service.findById(req.query.id).populate("user");

  if (!serv) return next(new appError("هذه الخدمة غير موجودة", 404));

  const services = await service
    .find({ user: serv.user.id })
    .populate("user");

  res.status(200).render("service", {
    title: "m3allam.ma | الخدمات",
    jobs,
    serv,
    services,
  });
});

// =============================================================== OUVRIER PAGE

exports.ouvrierPage = catchAsync(async (req, res, next) => {
  const services = await service.find({ user: req.query.id }).populate("user");
  if (!services) return next(new appError("هذه الخدمة غير موجودة", 404));

  const auser = await user.findById(req.query.id);
  if (!auser) return next(new appError("هذا العامل غير موجود", 404));

  res.status(200).render("ouvrier", {
    title: "m3allam.ma | عامل",
    jobs,
    services,
    auser,
  });
});
