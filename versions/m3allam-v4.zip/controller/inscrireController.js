const fs = require("fs");
const user = require("../model/userModel");
const authToken = require("../utils/authToken");
const appError = require("../utils/appErrors");
const catchAsync = require("../utils/catchAsync");
const multer = require("multer");
const sharp = require("sharp");
const slugify = require("slugify");

const jobs = JSON.parse(fs.readFileSync(`${__dirname}/../json/jobs.json`));
const jihat = JSON.parse(fs.readFileSync(`${__dirname}/../json/jiha.json`));

// ========================= PICTURE CROP

const multerStorage = multer.memoryStorage();

const multerFilter = (req, file, cb) => {
  if (file.mimetype.startsWith("image")) {
    cb(null, true);
  } else {
    cb(new appError("ليست صورة! يرجى تحميل الصور فقط", 400), false);
  }
};

const upload = multer({
  storage: multerStorage,
  fileFilter: multerFilter,
});

exports.uploadStoreLogo = upload.single("picture");

exports.resizeStoreLogo = catchAsync(async (req, res, next) => {
  if (!req.file) return next();

  req.file.filename = `worker-${req.query.phone}-${Date.now()}.png`;
  await sharp(req.file.buffer)
    .resize(200, 200)
    .toFormat("png")
    .jpeg({ quality: 90 })
    .toFile(`${__dirname}/../graphics/worker/${req.file.filename}`);
  next();
});

// ========================= GET

exports.inscrirePage = (req, res) => {
  res.status(200).render("inscrire", {
    title: "m3allam.ma | انشاء حساب",
    jobs,
    jihat,
    phone: req.query.phone,
  });
};

exports.seConnecterPage = (req, res) => {
  res.status(200).render("seConnecter", {
    title: "m3allam.ma | تسجيل الدخول",
  });
};

// ========================= POST

exports.inscrireSave = catchAsync(async (req, res, next) => {
  const userConnect = await user.findOneAndUpdate(
    { phone: `+212${req.query.phone.substring(1)}` },
    {
      name: req.body.name,
      jiha: req.body.jiha,
      city: JSON.parse(req.body.city),
      whatsapp: req.body.whatsapp,
      valid: "oui",
      photo: req.file.filename,
    }
  );

  if (!userConnect) {
    return next(
      new appError("حدث خطأ ما. لم يتم إنشاء الحساب، أعد المحاولة من فضلك", 500)
    );
  }

  const token = authToken.createSendToken(userConnect._id);
  const cookieOptions = authToken.cookieOptions;
  res.cookie("cookie", token, cookieOptions);
  res.redirect(`/mon-compte/${userConnect.id}`);
});

exports.seConnecterPost = catchAsync(async (req, res, next) => {
  const existUser = await user.findOne({
    phone: `+212${req.body.phone.substring(1)}`,
  });


  if (existUser && existUser.valid === "oui") {
    const token = authToken.createSendToken(existUser._id);
    const cookieOptions = authToken.cookieOptions;
    res.cookie("cookie", token, cookieOptions);
    return res.redirect("/");
  }
  
  if (existUser && existUser.valid === "non") {
    return res.redirect(`/inscrire?phone=${req.body.phone}`);
  }

  const newUser = await user.create({
    name: "xxxxx",
    jiha: "xxxxx",
    city: "xxxxx",
    phone: "+212" + req.body.phone.substring(1),
  });
  if (!newUser)
    return next(
      new appError("حدث خطأ ما. لم يتم تسجيل الدخول، أعد المحاولة من فضلك", 500)
    );

  res.redirect(`/inscrire?phone=${req.body.phone}`);
});
