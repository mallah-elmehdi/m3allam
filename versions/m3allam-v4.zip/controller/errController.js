const appError = require("../utils/appErrors");

exports.indexError = (err, req, res, next) => {
  if (!err.statusCode) return next(new appError("حدث خطأ ما. أعد المحاولة من فضلك", 500));
  else if (err.statusCode === 500 || err.statusCode === 404) return next();
  else if (err.kind && err.kind === "ObjectId")
    return next(new appError("الصفحة غير موجودة", 404));

  res.redirect(`/?message=${err.message}&status=${err.statusCode}`);
};

exports.globalError = (err, req, res, next) => {
  res.status(err.statusCode).render("404", {
    title: "⚠️ خطأ",
    status: err.statusCode,
    message: err.message,
  });
};
